# vuex-shopcart
[DEMO](https://liuxingzhijian1320.github.io/vuex-shopcart/index.html)

> vuex实现的简单的demo


# 安装依赖
npm install

# 启动server
npm run dev

# 编译发布
npm run build
```
