<template>
  <div class="uk-background-gray-lightest uk-padding-top-small uk-padding-bottom-largest">
    <!--<pictextContact :data="$store.state.componentDatas.pictextContact"></pictextContact>-->

    <div class="uk-margin-top container ">

         {{$store.state.componentData[$route.params.id]}}


    </div>


  </div>

</template>
<script>

  import pictextContact from '@/components/pictextContact/'
  import articleA from '@/components/articleA/index.vue'


  export default {

    components: {pictextContact, articleA},
    async fetch({store, params}) {


      await store.dispatch('getComponentDataById', params.id);
    },


  }
</script>

<style lang="less" module>
  :global .collapse-nav {
    a {
      //无法在这这里用mixin,因为嵌套也改选择器的名字
      .hover-underline();
      .hover-underline-left();
      display: block;
      padding: 15px;

    }
  }
</style>
