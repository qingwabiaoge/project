<template>
  <div class="uk-background-gray-lightest  uk-padding-bottom-largest">


   <div class="uk-text-center">
     <img src="@/assets/pic/joinbg.jpg" style="width: 100%" alt="艺术涂料加盟">
   </div>

    <div class="uk-margin-top container ">

      <el-row :gutter="30">
        <el-col :md="6">
          <titlebarA icon="xinwenzixun"
                     title="加盟支持"
                     subTitle="JOIN US"
                     class="uk-border-bottom">

          </titlebarA>

          <div class="uk-background-default uk-padding-bottom-large uk-padding-top">
            <nuxt-link
                       class="uk-display-block hover-underline hover-underline-left "
                       style="padding: 15px 0 15px 30px"
                        v-for="item in $store.state.articles.join"
                       :key="item._id"
                        :to="{path:`/join/${item._id}`}">
              {{item.title}}
            </nuxt-link>

          </div>

          <titlebarA icon="xiazai"
                     title="联系我们"
                     subTitle="CONTACT US"
                     class="uk-border-bottom uk-margin-top uk-hidden@xs">

          </titlebarA>

          <pictextContactSiderbar class="uk-hidden@xs"></pictextContactSiderbar>


        </el-col>
        <el-col :md="18">
          <articleA :data="$store.state.article[$route.params.id]"></articleA>

        </el-col>

      </el-row>


    </div>


  </div>

</template>
<script>

  import pictextContact from '@/components/pictextContact/'
  import articleA from '@/components/articleA/index.vue'
  import pictextContactSiderbar from '@/components/pictextContactSiderbar/index'



  export default {
    created(){
      console.log(this.$route)
    },
    components: {pictextContact, articleA,pictextContactSiderbar},
    async fetch({store, params}) {
      await store.dispatch('getArticles', {componentName: "join", category: '代理加盟'});
      await store.dispatch('getComponentDatas', 'pictextContact');

      await store.dispatch('getArticleById', params.id);
    },


  }
</script>

<style lang="less" module>
  :global .collapse-nav {
    a {
      //无法在这这里用mixin,因为嵌套也改选择器的名字
      .hover-underline();
      .hover-underline-left();
      display: block;
      padding: 15px;

    }
  }
</style>
