<template>
  <div></div>
</template>
<script>

  export default{
    created(){
      console.log(this.$route)
    },
    async asyncData ({ app , req , redirect , route }){

      redirect({ path: '/join/5c1a6a4590d3e023a052d9aa' })

    }
  }


</script>
