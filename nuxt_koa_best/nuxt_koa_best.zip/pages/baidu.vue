<template>
  <baidu></baidu>

</template>

<script>
  import baidu from '@/components/baidu'

  export default {

    components:{baidu}
  }

</script>
