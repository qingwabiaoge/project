// 其他业务常量

module.exports = {
    user: {
        role: 'administer',
        username: 'best',
        password: 'best@168',
        email: 'qq22337383@gmail.com',
        nickname: 'xxx',
        avatar: 'el-icon-success'
    },
    adminJwtString: 'qinshilei',
    vipJwtString: 'qinshilei',
    dataBash: 'mongodb://localhost:27017/best',
    // host: "127.0.0.1",
    // port: 5757,
    apiBase: '/api',
    uploadBase: '/upload',
    // adminApp: {
    //     domain: '',
    //     host: '127.0.0.1',
    //     port: 5757,
    //     routerBase: '/admin'
    // },
    // clientApp: {
    //     routerBase: '/client'
    // },
    OSS: {
        region: 'oss-cn-shenzhen', //自定义项
        accessKeyId: 'LTAIyaBw7R06PSPd', //自定义项
        accessKeySecret: 'bn4PlObQQjbhBInkuxrNRd3P79dcHQ' //自定义项
    }
    ,


    // 小程序账户
    appid: 'wxcee026337cd578de',
    appsecret: '689ed5600168c7e66f7f13175057592c',

// 微信商户
    mchid: 1499761962, //一定要数字
    apikey: '12313131adadsfdasdfDDFEWWWEEE111',

    articlePageSize: 15
}
;

