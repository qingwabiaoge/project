export default {
  //远程主机地址
  goodsCategory: [{
    path: '/goods/幻彩漆',
    value: '幻彩漆',
    label: '幻彩漆',//select显示文字
    text: '幻彩漆', //筛选器显示文字
    evalue: 'FANCY PAINT',
    ico: 'jiaju-danrenshafa'

  },
    {
      path: '/goods/丽彩丝缎',
      value: '丽彩丝缎',
      label: '丽彩丝缎',//select显示文字
      text: '丽彩丝缎', //筛选器显示文字
      evalue: 'FANCY PAINT',
      ico: 'jiaju-danrenshafa'
    },
    {
      path: '/goods/丽彩丝绒',
      value: '丽彩丝绒',
      label: '丽彩丝绒',//select显示文字
      text: '丽彩丝绒', //筛选器显示文字
      evalue: 'FANCY PAINT',
      ico: 'jiaju-danrenshafa'
    },
    {
      path: '/goods/叠影',
      value: '叠影',
      label: '叠影',//select显示文字
      text: '叠影', //筛选器显示文字
      evalue: 'FANCY PAINT',
      ico: 'jiaju-danrenshafa'
    },
    {
      path: '/goods/水性底漆',
      value: '水性底漆',
      label: '水性底漆',//select显示文字
      text: '水性底漆', //筛选器显示文字
      evalue: 'FANCY PAINT',
      ico: 'jiaju-danrenshafa'
    },
    {
      path: '/goods/丽彩砂',
      value: '丽彩砂',
      label: '丽彩砂',//select显示文字
      text: '丽彩砂', //筛选器显示文字
      evalue: 'FANCY PAINT',
      ico: 'jiaju-danrenshafa'
    },
    {
      path: '/goods/艺术辅料',
      value: '艺术辅料',
      label: '艺术辅料',//select显示文字
      text: '艺术辅料', //筛选器显示文字
      evalue: 'FANCY PAINT',
      ico: 'jiaju-danrenshafa'
    },
    {
      path: '/goods/瓦格丝特',
      value: '瓦格丝特',
      label: '瓦格丝特',//select显示文字
      text: '瓦格丝特', //筛选器显示文字
      evalue: 'FANCY PAINT',
      ico: 'jiaju-danrenshafa'
    },
    {
      path: '/goods/印花水漆',
      value: '印花水漆',
      label: '印花水漆',//select显示文字
      text: '印花水漆', //筛选器显示文字
      evalue: 'FANCY PAINT',
      ico: 'jiaju-danrenshafa'
    },

    {
      path: '/goods/银彩系列',
      value: '银彩系列',
      label: '银彩系列',//select显示文字
      text: '银彩系列', //筛选器显示文字
      evalue: 'FANCY PAINT',
      ico: 'jiaju-danrenshafa'
    },


  ],

  //article 栏目
  articleCategory: [

    {
      value: '公司新闻',
      label: '公司新闻',//select显示文字
      text: '公司新闻' //筛选器显示文字
    },
    {
      value: '行业新闻',
      label: '行业新闻'
      , text: '行业新闻'
    }
  ],


}
